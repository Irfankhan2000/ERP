﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form3 : Form
    {
        Form1 conn = new Form1();
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
            {
                conn.oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("Update Vendor set VStatus='Approved' where VID=@VID", conn.oleDbConnection1);

                cmd.Parameters.AddWithValue("@VID", comboBox1.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Approved Vendor");

                conn.oleDbConnection1.Close();
            }
            else if(this.radioButton3.Checked)
            {
              conn.oleDbConnection1.Open();
              OleDbCommand cmd = new OleDbCommand("Update po set Status='close'  where VID=@VID", conn.oleDbConnection1);
              cmd.Parameters.AddWithValue("@VID", comboBox1.Text);
              cmd.ExecuteNonQuery();
              MessageBox.Show(" Approved PO");

              conn.oleDbConnection1.Close();
            }
            else if (this.radioButton2.Checked)
            {
                conn.oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("Update Invoice set Approval='close'  where POID=@POID", conn.oleDbConnection1);
                cmd.Parameters.AddWithValue("@POID", comboBox1.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Approved Invoice");

                conn.oleDbConnection1.Close();
            }
        
        }


        private void Form3_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
          conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Vendor  where VStatus='SFA'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            comboBox1.Items.Clear();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["VId"].ToString());
            }
            conn.oleDbConnection1.Close();
           
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
          

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (this.radioButton1.Checked)
            {
                conn.oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("Update Vendor set VStatus='Dispproved' where VID=@VID", conn.oleDbConnection1);

                cmd.Parameters.AddWithValue("@VID", comboBox1.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Approved Vendor");

                conn.oleDbConnection1.Close();
            }
            else if (this.radioButton3.Checked)
            {
                conn.oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("Update po set Status='close'  where VID=@VID", conn.oleDbConnection1);
                cmd.Parameters.AddWithValue("@VID", comboBox1.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Disapproved PO");

                conn.oleDbConnection1.Close();
            }
            else if (this.radioButton2.Checked)
            {
                conn.oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("Update Invoice set Approval='close'  where POID=@POID", conn.oleDbConnection1);
                cmd.Parameters.AddWithValue("@POID", comboBox1.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show(" Disapproved Invoice");

                conn.oleDbConnection1.Close();
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Vendor  where VStatus='SFA'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            conn.oleDbConnection1.Close();

            conn.oleDbConnection1.Open();
            OleDbCommand cmd1= new OleDbCommand("select *from Vendor  where VStatus='SFA'", conn.oleDbConnection1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            comboBox1.Items.Clear();
            while (dr1.Read())
            {
                comboBox1.Items.Add(dr1["VId"].ToString());
            }
            conn.oleDbConnection1.Close();
           
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {

            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select *from po where Status='open'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            conn.oleDbConnection1.Close();

            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select *from po  where Status='open'", conn.oleDbConnection1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            comboBox1.Items.Clear();
            while (dr1.Read())
            {
                comboBox1.Items.Add(dr1["VId"].ToString());
            }
            conn.oleDbConnection1.Close();
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select *from Invoice where Approval='Applied'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            conn.oleDbConnection1.Close();

            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select  * from Invoice  where Approval='Applied'", conn.oleDbConnection1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
           this.comboBox1.Items.Clear();
            while (dr1.Read())
            {
                comboBox1.Items.Add(dr1["POID"].ToString());
            }
            conn.oleDbConnection1.Close();
        }
    }
}
