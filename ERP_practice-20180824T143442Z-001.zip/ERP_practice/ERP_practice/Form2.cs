﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;


namespace WindowsFormsApplication1
{
    public partial class Form2 : Form
    {
        Form1 conn = new Form1();
        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

            Form3 f3 = new Form3();
            f3.Show();
            
            

            

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.panel3.Visible = false;          
  
            this.panel2.Visible = false;
        conn.oleDbConnection1.Open();
            OleDbCommand icmd = new OleDbCommand("select GRNID from grn where status='Open'",conn.oleDbConnection1);
            OleDbDataReader idr = icmd.ExecuteReader();
            while (idr.Read())
            {
                this.comboBox1.Items.Add(idr["grnid"].ToString());

            }
          conn.oleDbConnection1.Close();
         

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {



            this.panel2.Visible = true;
            this.panel3.Visible = false;
      


           

            


        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into  Vendor(VID,VName,VCode,VCity,PH1,PH2,VAddress,CPName,CPPH,VEmail,VFax,VGroup,VStatus) values(@VID,@VName,@VCode,@VCity,@PH1,@PH2,@VAddress,@CPName,@CPPH,@VEmail,@VFax,@VGroup,@VStatus);", conn.oleDbConnection1);

             cmd.Parameters.AddWithValue("@VId",this.textBox1.Text).ToString();
             cmd.Parameters.AddWithValue("@VName", this.textBox2.Text);
             cmd.Parameters.AddWithValue("@VCode", this.textBox3.Text).ToString();
             cmd.Parameters.AddWithValue("@VCity", this.textBox4.Text);
             cmd.Parameters.AddWithValue("@PH1", this.textBox5.Text).ToString();
             cmd.Parameters.AddWithValue("@PH2", this.textBox6.Text).ToString();
             cmd.Parameters.AddWithValue("@VAddress", this.textBox7.Text);
             cmd.Parameters.AddWithValue("@CPName", this.textBox8.Text);
             cmd.Parameters.AddWithValue("@CPPH", this.textBox9.Text).ToString();
             cmd.Parameters.AddWithValue("@VEmail", this.textBox10.Text);
             cmd.Parameters.AddWithValue("@VFax", this.textBox11.Text).ToString();
             cmd.Parameters.AddWithValue("@VGroup", this.textBox12.Text);
             cmd.Parameters.AddWithValue("@VStatus", "SFA");
             cmd.ExecuteNonQuery();
             MessageBox.Show("send for approval");
            




            conn.oleDbConnection1.Close();


        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label25_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label27_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.panel2.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {

            Form5 f5 = new Form5();
            f5.Show();
        }

        private void label7_Click(object sender, EventArgs e)
        {
            this.panel3.Visible = true;
            this.panel2.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
          conn.oleDbConnection1.Open();
            OleDbCommand cmd2 = new OleDbCommand("insert into invoice (invoiceid,poid,vendorname,ddate,grndate,invoicedate,amountpayable,grnid,approval) values(@invoiceid,@poid,@vendorname,@ddate,@grndate,@invoicedate,@amountpayable,@grnid,@approval)",conn.oleDbConnection1);
            cmd2.Parameters.AddWithValue("@InvoiceID", textBox14.Text);
            cmd2.Parameters.AddWithValue("@poid", textBox19.Text);
            cmd2.Parameters.AddWithValue("@VendorName", textBox17.Text);
            cmd2.Parameters.AddWithValue("@ddate", textBox15.Text);
            cmd2.Parameters.AddWithValue("@GRNDate", textBox18.Text);
            cmd2.Parameters.AddWithValue("@InvoiceDate", System.DateTime.Today);
            cmd2.Parameters.AddWithValue("@AmountPayable", textBox16.Text);
            cmd2.Parameters.AddWithValue("@GRNID", comboBox1.Text);
            cmd2.Parameters.AddWithValue("@Approval", "Applied");
            cmd2.ExecuteNonQuery();
         
           conn.oleDbConnection1.Close();
           MessageBox.Show("Data inserted");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from GRN where GRNID='"+comboBox1.Text+"'",conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read()) {
                textBox15.Text = dr["DDate"].ToString();
                textBox18.Text = dr["GRDate"].ToString();
                textBox19.Text = dr["POID"].ToString();
                textBox17.Text=dr["VName"].ToString();
            }
           
            conn.oleDbConnection1.Close();
            this.textBox14.Text = "INV-" + comboBox1.Text;
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Text = "SO Invoice";
            f6.Show();
            f6.panel1.Visible = false;
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();

            f6.panel1.Visible = true;
            
        }

        private void label42_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.Show();
           f4.panel4.Visible = true;
           
          
            
            
        }

        private void label43_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.Show();
          f6.panel1.Visible = false;
       
            f6.panel3.Visible = true;

            
            
        }

        private void label23_Click(object sender, EventArgs e)
        {

        }
    }
}
