﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        Form1 conn = new Form1();
        string[] prd = new string[50];
        int[] qty = new int[50];
        int [] pprice =new int[60];
        int counter = 0;
        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;

            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from vendor ", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                this.comboBox2.Items.Add(dr["vid"].ToString());
            }
            conn.oleDbConnection1.Close();


            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select * from Dept ", conn.oleDbConnection1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {

                this.comboBox1.Items.Add(dr1["deptname"].ToString());
            }
            conn.oleDbConnection1.Close();





            conn.oleDbConnection1.Open();
            OleDbCommand cmd2 = new OleDbCommand("select * from Products ", conn.oleDbConnection1);
            OleDbDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {

                this.comboBox3.Items.Add(dr2["Pid"].ToString());
            }
            conn.oleDbConnection1.Close();

          

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Vendor  where VId='" + comboBox2.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox2.Text = dr["VName"].ToString();
                textBox3.Text = dr["VCity"].ToString();
                textBox4.Text = dr["PH1"].ToString();

            }
            conn.oleDbConnection1.Close();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Products  where Pid='" + comboBox3.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox5.Text = dr["PName"].ToString();
                textBox6.Text = dr["BasePrice"].ToString();

            }
            conn.oleDbConnection1.Close();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {



            int c = 0;
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select count(poid) from po where vdept='" + comboBox1.Text + "'", conn.oleDbConnection1);
           OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
          {
                c = Convert.ToInt32(dr[0]); c++;
            }
            if (comboBox1.Text == "Consumer")
            {
                textBox8.Text = "Con_00" + c.ToString() + "--" + System.DateTime.Today.Year;
           } if (comboBox1.Text == "HR")
           {
                textBox8.Text = "HR-01" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            if (comboBox1.Text == "Marketing")
            {
                textBox8.Text = "Mar-02" + c.ToString() + "-" + System.DateTime.Today.Year;
          } 
            if (comboBox1.Text == "Sales")
           {
                textBox8.Text = "sal-03" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            conn.oleDbConnection1.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                textBox1.Text += comboBox3.Text + Environment.NewLine;
                textBox9.Text += textBox6.Text + Environment.NewLine;
                prd[counter] = comboBox3.Text;
                qty[counter] = Convert.ToInt32(textBox7.Text);
                pprice[counter] = Convert.ToInt32(textBox6.Text);

                counter++;

            }catch(Exception ex)
            {
            }
    

        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            for (int i = 0; i < counter; i++)
            {
                OleDbCommand cmd1 = new OleDbCommand("insert into POProducts (poid,pid,pqty) values(@poid,@pid,@pqty)", conn.oleDbConnection1);
                cmd1.Parameters.AddWithValue("@poid", textBox8.Text).ToString();
                cmd1.Parameters.AddWithValue("@pid", prd[i]);
                cmd1.Parameters.AddWithValue("@pqty", qty[i]);

                cmd1.ExecuteNonQuery();
                            

            }
            conn.oleDbConnection1.Close();
           

            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into PO(poid,vdept,vname,vid,vcpph,podate,ddate,Status)values(@poid,@vdept,@vname,@vid,@vcpph,@podate,@ddate,@Status)", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@poid", this.textBox8.Text);
            cmd.Parameters.AddWithValue("@vdept", this.comboBox1.Text);
            cmd.Parameters.AddWithValue("@vname", this.textBox2.Text);
            cmd.Parameters.AddWithValue("@vid", this.comboBox2.Text);
            cmd.Parameters.AddWithValue("@vcpph", this.textBox4.Text);
            cmd.Parameters.AddWithValue("@podate", this.dateTimePicker1);
           cmd.Parameters.AddWithValue("@ddate", this.dateTimePicker1);
            cmd.Parameters.AddWithValue("@Status","open");
            cmd.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
            MessageBox.Show("Transaction done!!");



           

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.textBox2.Clear();
            this.textBox3.Clear();
            this.textBox4.Clear();
            this.textBox5.Clear();
            this.textBox1.Clear();
            this.textBox9.Clear();
           
            this.textBox6.Clear();
            this.textBox7.Clear();

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
        
         
     
        
    }
}


