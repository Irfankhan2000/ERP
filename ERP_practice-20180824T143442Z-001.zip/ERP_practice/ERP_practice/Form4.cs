﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        Form1 conn = new Form1();
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into grn (grnid,poid,vname,ddate,grdate,status) values(@grnid,@poid,@vname,@ddate,@grdate,@status)", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@grnid", textBox2.Text);
            cmd.Parameters.AddWithValue("@poid", comboBox1.Text);
            cmd.Parameters.AddWithValue("@vname", textBox3.Text);
            cmd.Parameters.AddWithValue("@ddate", textBox6.Text);
            cmd.Parameters.AddWithValue("grdate", System.DateTime.Today);
            cmd.Parameters.AddWithValue("@status", "Open");
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data inserted");
            conn.oleDbConnection1.Close();
            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("update po set status='Close' where poid='" + comboBox1.Text + "'", conn.oleDbConnection1);
            cmd1.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

            conn.oleDbConnection1.Open();
            OleDbCommand cmdii = new OleDbCommand("select SOID from SO  ", conn.oleDbConnection1);
            OleDbDataReader drii = cmdii.ExecuteReader();
            while (drii.Read())
            {
                this.comboBox4.Items.Add(drii["SOID"].ToString());

            }
            conn.oleDbConnection1.Close();
            this.panel4.Visible = false;
            this.WindowState = FormWindowState.Maximized;
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select POID from PO  where Status='close'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            comboBox1.Items.Clear();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["POID"].ToString());
            }
            conn.oleDbConnection1.Close();


        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("Select * from PO where POID='" + comboBox1.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox3.Text = dr["VName"].ToString();
                textBox4.Text = dr["VID"].ToString();
                textBox5.Text = dr["VContectPerson"].ToString();
                textBox7.Text = dr["VCPPH"].ToString();
                textBox6.Text = dr["PODate"].ToString();
            }

            conn.oleDbConnection1.Close();
            textBox2.Text = "GRN-" + comboBox1.Text;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from POProducts where POID =@POID", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@POID", comboBox1.Text);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            conn.oleDbConnection1.Close();
            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select * from PO where POID =@POID", conn.oleDbConnection1);
            cmd1.Parameters.AddWithValue("@POID", comboBox1.Text);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            DataTable dt1 = new DataTable();
            dt1.Load(dr1);
            dataGridView2.DataSource = dt1;
            conn.oleDbConnection1.Close();

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            this.Text = "SO challan";
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("Select * from SO where SOID='" + comboBox4.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox27.Text = dr["SODate"].ToString();
                textBox22.Text = dr["CID"].ToString();
                textBox23.Text = dr["CName"].ToString();
                textBox24.Text = dr["CContectPerson"].ToString();
                textBox25.Text = dr["CCPPH"].ToString();
                textBox6.Text = dr["RDate"].ToString();
                textBox1.Text = dr["TotalAmount"].ToString();
            }

            textBox26.Text = "SOC-" + comboBox4.Text ;
            conn.oleDbConnection1.Close();
          
    }

        private void button5_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into SOChallan(SOChallanID,SOID,Cname,RDate,SOChallanDate,status) values(@SOChallanID,@SOID,@Cname,@RDate,@SOChallanDate,@status)", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@SOChallanID", textBox26.Text);
            cmd.Parameters.AddWithValue("@SOID", comboBox1.Text);
            cmd.Parameters.AddWithValue("@Cname", textBox3.Text);
            cmd.Parameters.AddWithValue("@RDate", textBox6.Text);
            cmd.Parameters.AddWithValue("@SOChallanDate", this.dateTimePicker1);
            cmd.Parameters.AddWithValue("@PayAmount", textBox1.Text);
            cmd.Parameters.AddWithValue("@status", "Open");
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data inserted");
            conn.oleDbConnection1.Close();
        }
    }
}
