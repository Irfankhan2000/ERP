﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form8 : Form
    {
        Form1 conn = new Form1();
        string[] prd = new string[50];
        int[] qty = new int[50];
        int[] pprice = new int[60];
        int counter = 0;
        public Form8()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into Customer(Cid,CName,CAddress,City,Ph1,Ph2,ContectPerson,CPPH,CEmail,CreditLimit,CStatus,CGroup) values(@CID,@CName,@CAddress,@City,@PH1,@PH2,@ContectPerson,@CPPH,@CEmail,@CreditLimit,@CStatus,@CGroup)", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@CID", textBox10.Text);
            cmd.Parameters.AddWithValue("@CName", textBox1.Text);
            cmd.Parameters.AddWithValue("@CAddress", textBox2.Text);
            cmd.Parameters.AddWithValue("@City", textBox3.Text);
            cmd.Parameters.AddWithValue("@PH1", textBox4.Text);
            cmd.Parameters.AddWithValue("@PH2", textBox5.Text);
            cmd.Parameters.AddWithValue("@ContectPerson", textBox6.Text);
            cmd.Parameters.AddWithValue("@CPPH", textBox7.Text);
            cmd.Parameters.AddWithValue("@CEmail", textBox8.Text);
            cmd.Parameters.AddWithValue("@CreditLimit", textBox9.Text);
            cmd.Parameters.AddWithValue("@CStatus", "Inactive");
            cmd.Parameters.AddWithValue("@CGroup", textBox12);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Has been Inserted");
            conn.oleDbConnection1.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            this.panel1.Visible = false;
            this.panel2.Visible = false;
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select CID from Customer ", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            comboBox1.Items.Clear();
            while (dr.Read())
            {
                comboBox1.Items.Add(dr["CID"].ToString());
            }

            conn.oleDbConnection1.Close();
            this.comboBox1.Visible = false;
            this.label11.Visible = false;

            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("select deptname from Dept", conn.oleDbConnection1);
            OleDbDataReader dr1 = cmd1.ExecuteReader();
            while (dr1.Read())
            {
                comboBox2.Items.Add(dr1["deptname"]);

            }
            conn.oleDbConnection1.Close();

            conn.oleDbConnection1.Open();
            OleDbCommand cmd2 = new OleDbCommand("select * from Products ", conn.oleDbConnection1);
            OleDbDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {

                this.comboBox3.Items.Add(dr2["Pid"].ToString());
            }
            conn.oleDbConnection1.Close();

            conn.oleDbConnection1.Open();
            OleDbCommand cmd3 = new OleDbCommand("select CID from Customer where CStatus='Active '", conn.oleDbConnection1);
            OleDbDataReader dr3 = cmd3.ExecuteReader();
            while (dr3.Read())
            {
                comboBox4.Items.Add(dr3["CID"]);
            }
            conn.oleDbConnection1.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("update Customer set CName=@cname,CAddress=@caddress,City=@city,Ph1=@ph1,Ph2=@ph2,ContectPerson=@contectperson,CPPH=@cpph,CEmail=@cemail,CreditLimit=@creditlimit,CStatus=@cstatus,CGroup=@cgroup where cid='" + textBox10.Text + "'", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@CName", textBox1.Text);
            cmd.Parameters.AddWithValue("@CAddress", textBox2.Text);
            cmd.Parameters.AddWithValue("@City", textBox3.Text);
            cmd.Parameters.AddWithValue("@PH1", textBox4.Text);
            cmd.Parameters.AddWithValue("@PH2", textBox5.Text);
            cmd.Parameters.AddWithValue("@ContectPerson", textBox6.Text);
            cmd.Parameters.AddWithValue("@CPPH", textBox7.Text);
            cmd.Parameters.AddWithValue("@CEmail", textBox8.Text);
            cmd.Parameters.AddWithValue("@CreditLimit", textBox9.Text);
            cmd.Parameters.AddWithValue("@CStatus", "Inactive");
            cmd.Parameters.AddWithValue("@CGroup", textBox12);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data Has been Updated");
            conn.oleDbConnection1.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.comboBox1.Visible = true;
            this.label11.Visible = true;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from customer where cid='" + comboBox1.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                this.textBox1.Text = dr["cname"].ToString();
                this.textBox2.Text = dr["caddress"].ToString();
                this.textBox3.Text = dr["city"].ToString();
                this.textBox4.Text = dr["ph1"].ToString();
                this.textBox5.Text = dr["ph2"].ToString();
                this.textBox6.Text = dr["contectperson"].ToString();
                this.textBox7.Text = dr["cpph"].ToString();
                this.textBox8.Text = dr["cemail"].ToString();
                this.textBox9.Text = dr["creditlimit"].ToString();
                this.textBox12.Text = dr["cgroup"].ToString();


            }
            conn.oleDbConnection1.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int c = 0;
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select count(SOID) from SO where CDept='" + comboBox2.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                c = Convert.ToInt32(dr[0]);
                c++;
            }
            if (comboBox2.Text == "Consumer")
            {
                textBox13.Text = "Con-00" + c.ToString() + "-" + System.DateTime.Today.Year;
            } if (comboBox2.Text == "HR")
            {
                textBox13.Text = "HR-00" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            if (comboBox2.Text == "Marketing")
            {
                textBox13.Text = "Mar-00" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            if (comboBox2.Text == "Sales")
            {
                textBox13.Text = "sal-00" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            conn.oleDbConnection1.Close();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Products  where Pid='" + comboBox3.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox11.Text = dr["PName"].ToString();
                textBox14.Text = dr["BasePrice"].ToString();

            }
            conn.oleDbConnection1.Close();
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Customer where CID='" + comboBox4.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                textBox16.Text = dr["Cname"].ToString();
                textBox17.Text = dr["CAddress"].ToString();
                textBox18.Text = dr["Contectperson"].ToString();
                textBox19.Text = dr["Cpph"].ToString();
            }
            conn.oleDbConnection1.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            prd[counter] = comboBox3.Text;
            qty[counter] = Convert.ToInt32(textBox21.Text);
            pprice[counter] = Convert.ToInt32(textBox14.Text);

            counter++;
            string a, b;
            a = this.textBox14.Text.ToString();
            b = this.textBox21.Text.ToString();

            // textBox15.Text += comboBox3.Text + "       " + this.textBox14.Text + "     x    " + this.textBox21.Text + "  =  " + this.textBox14.Text.ToString()+ * this.textBox21.Text.;
           textBox15.Text += comboBox3.Text + "       " + this.textBox14.Text + "     x    " + this.textBox21.Text + "  =  " + Convert.ToInt32(a) * Convert.ToInt32(b) + Environment.NewLine;

            //textBox15.Text += prd[] + "    " + qty[counter] + "  x  " + pprice[counter] + "     =   " + qty[counter] * pprice[counter] + Environment.NewLine; 


        }

        private void button5_Click(object sender, EventArgs e)
        {

            try
            {
                conn.oleDbConnection1.Open();
                for (int i = 0; i < counter; i++)
                {
                    OleDbCommand cmd1 = new OleDbCommand("insert into SOProducts (SOID,pid,PQty,PPrice) values(@SOID,@pid,@PQty,@PPrice)", conn.oleDbConnection1);
                    cmd1.Parameters.AddWithValue("@SOId", textBox13.Text).ToString();
                    cmd1.Parameters.AddWithValue("@pid", prd[i]);
                    cmd1.Parameters.AddWithValue("@pqty", qty[i]);
                    cmd1.Parameters.AddWithValue("@PPrice", pprice[i]);
                    cmd1.ExecuteNonQuery();
                }




                conn.oleDbConnection1.Close();
                MessageBox.Show("done");
            }
            catch(Exception ex)
            {
                MessageBox.Show("there is some error");
            }




        }


    }
}
