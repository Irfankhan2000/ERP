﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          /* oleDbConnection1.Open();
            OleDbCommand cmd2 = new OleDbCommand("insert into invoice (invoiceid,poid,vendorname,ddate,grndate,invoicedate,amountpayable,grnid,approval) values(@invoiceid,@poid,@vendorname,@ddate,@grndate,@invoicedate,@amountpayable,@grnid,@approval)", oleDbConnection1);
            cmd2.Parameters.AddWithValue("@invoiceid", textBox32.Text);
            cmd2.Parameters.AddWithValue("@poid", textBox27.Text);
            cmd2.Parameters.AddWithValue("@vendorname", textBox28.Text);
            cmd2.Parameters.AddWithValue("@ddate", textBox24.Text);
            cmd2.Parameters.AddWithValue("@grndate", textBox25.Text);
            cmd2.Parameters.AddWithValue("@invoicedate", System.DateTime.Today);
            cmd2.Parameters.AddWithValue("@amountpayable", textBox23.Text);
            cmd2.Parameters.AddWithValue("@grnid", comboBox7.Text);
            cmd2.Parameters.AddWithValue("@approval", "Applied");
            cmd2.ExecuteNonQuery();
            MessageBox.Show("Data inserted");
            oleDbConnection1.Close();*/
        }

        private void Form7_Load(object sender, EventArgs e)
        {

        }
    }
}
