﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;

namespace WindowsFormsApplication1
{
    public partial class Form6 : Form
    {
        Form1 conn = new Form1();
        string[] prd = new string[50];
        int[] qty = new int[50];
        int[] pprice = new int[60];
        int counter = 0;

        int a = 0;
        int flag = 0; 
        public Form6()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                conn.oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("insert into  Customer(CID,Cname,CAddress,City,PH1,PH2,ContectPerson,CPPH,CEmail,CreditLimit,CGroup) values(@CID,@Cname,@CAddress,@City,@PH1,@PH2,@ContectPerson,@CPPH,@CEmail,@CreditLimit,@CGroup);", conn.oleDbConnection1);

                cmd.Parameters.AddWithValue("@CID", this.textBox1.Text).ToString();
                cmd.Parameters.AddWithValue("@Cname", this.textBox2.Text);
                cmd.Parameters.AddWithValue("@CAddress", this.textBox3.Text);
                cmd.Parameters.AddWithValue("@City", this.textBox4.Text);
                cmd.Parameters.AddWithValue("@PH1", this.textBox5.Text).ToString();
                cmd.Parameters.AddWithValue("@PH2", this.textBox6.Text).ToString();
                cmd.Parameters.AddWithValue("@Contectperson", this.textBox7.Text);
                cmd.Parameters.AddWithValue("@CPPH", this.textBox12.Text).ToString();
                cmd.Parameters.AddWithValue("@CEmail", this.textBox13.Text);
                cmd.Parameters.AddWithValue("@CreditLimit", this.textBox14.Text).ToString();
                cmd.Parameters.AddWithValue("@CGroup", this.textBox15.Text);
                cmd.Parameters.AddWithValue("@Cstatus", "Inactive");
                cmd.ExecuteNonQuery();
                MessageBox.Show("Data has been inserted");
            }
            catch( Exception ex)
    
            {
                MessageBox.Show("There is Some Issue to Perform the Operation");
                
            }



            conn.oleDbConnection1.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
             
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into SO(SOID,SODate,RDate,CName,CID,CContectPerson,CCPPh,TotalAmount,Status,Approve) values(@SOID,@SODate,@RDate,@CName,@CID,@CContectPerson,@CCPPh,@TotalAmount,@Status,@Approve)",conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@SOID", this.textBox17.Text);
            cmd.Parameters.AddWithValue("@SODate",this.dateTimePicker1);
            cmd.Parameters.AddWithValue("@RDate", this.dateTimePicker2);
            //cmd.Parameters.AddWithValue("@CDept", comboBox1.Text);
            cmd.Parameters.AddWithValue("@CName",this.textBox8.Text);
            cmd.Parameters.AddWithValue("@CID", this.comboBox3.Text);
            cmd.Parameters.AddWithValue("@ CContectPerson", this.textBox11.Text);
            cmd.Parameters.AddWithValue("@CCPPH", this.textBox16.Text);
            cmd.Parameters.AddWithValue("@TotalAmount",this.textBox37.Text);
            cmd.Parameters.AddWithValue("@Status", "Open");
            cmd.Parameters.AddWithValue("@Approve", "applied");
           // cmd.Parameters.AddWithValue("@SOprice", textBox18.Text).ToString();
            cmd.ExecuteNonQuery();
           
           conn.oleDbConnection1.Close();
           MessageBox.Show("Data  Inserted");
         conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("insert into soproducts (soid,pid,pqty) values(@soid,@pid,@pqty)", conn.oleDbConnection1);
            cmd1.Parameters.AddWithValue("@soid", textBox17.Text);
            cmd1.Parameters.AddWithValue("@pid", comboBox2.Text);
            cmd1.Parameters.AddWithValue("@pqty",textBox9);
            cmd1.ExecuteNonQuery();
          conn. oleDbConnection1.Close();
        }

        private void textBox17_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {
           
            this.comboBox6.Visible = false;
          
            conn.oleDbConnection1.Open();
            OleDbCommand icmd = new OleDbCommand("select SOChallanID from SOChallan where status='Open'", conn.oleDbConnection1);
            OleDbDataReader idr = icmd.ExecuteReader();
            while (idr.Read())
            {
                this.comboBox5.Items.Add(idr["SOChallanID"].ToString());

            }
            conn.oleDbConnection1.Close();

            conn.oleDbConnection1.Open();
            OleDbCommand cmdi = new OleDbCommand("select CID from Customer  ", conn.oleDbConnection1);
            OleDbDataReader dri = cmdi.ExecuteReader();
            while (dri.Read())
            {
                this.comboBox6.Items.Add(dri["CID"].ToString());

            }
            conn.oleDbConnection1.Close();
            
            
          
            conn.oleDbConnection1.Open();
            OleDbCommand cmdii = new OleDbCommand("select CID from Customer  ", conn.oleDbConnection1);
            OleDbDataReader drii = cmdii.ExecuteReader();
            while (drii.Read())
            {
                this.comboBox3.Items.Add(drii["CID"].ToString());

            }
            conn.oleDbConnection1.Close();
            conn.oleDbConnection1.Open();
            OleDbCommand cm = new OleDbCommand("select deptname from Dept  ", conn.oleDbConnection1);
            OleDbDataReader d = cm.ExecuteReader();
            while (d.Read())
            {
                this.comboBox1.Items.Add(d["deptname"].ToString());

            }
            conn.oleDbConnection1.Close();
            conn.oleDbConnection1.Open();
            OleDbCommand c = new OleDbCommand("select pid from products  ", conn.oleDbConnection1);
            OleDbDataReader di = c.ExecuteReader();
            while (di.Read())
            {
                this.comboBox2.Items.Add(di["pid"].ToString());

            }
            conn.oleDbConnection1.Close();

            
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
              
               
          
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void button7_Click(object sender, EventArgs e)
        {

            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into SOInvoice(SOInvoiceID,AmountRecive,RDate,SOChallanDate,CustomerName) values(@SOInvoiceID,@AmountRecive,@RDate,@SOChallanDate,@CustomerName)", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@SOInvoiceID", textBox35.Text);
            cmd.Parameters.AddWithValue("@AmountRecive", textBox33.Text);
            cmd.Parameters.AddWithValue("@RDate", textBox34.Text);
            cmd.Parameters.AddWithValue("@SOChallanDate", this.textBox31.Text);
            
            cmd.Parameters.AddWithValue("@CustomerName", this.textBox32.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data inserted");
            conn.oleDbConnection1.Close();
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
           this.textBox35.Text = "IN-" + this.comboBox5.Text;
                
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select *  from SOChallan where SOChallanID='"+comboBox5.Text+"'",conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
           //textBox35.Text=dr["SOIID"].ToString();
           textBox31.Text = dr["SOChallanDate"].ToString();
           textBox34.Text = dr["RDate"].ToString();
           //textBox30.Text = dr["CID"].ToString();
           textBox32.Text = dr["Cname"].ToString();
         //  textBox30.Text = dr["Cname"].ToString();
           textBox33.Text = dr["PayAmount"].ToString();
            }
            conn.oleDbConnection1.Close();
            textBox35.Text = "IN-" + System.DateTime.Today.Year;
           
            }

        private void label20_Click(object sender, EventArgs e)
        {

        }

        private void label41_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("insert into so (soid,sodate,rdate,cdept,cname,cid,ccontectperson,ccpph,totalamount,status,approve)values(@soid,@sodate,@rdate,@cdept,@cname,@cid,@ccontectperson,@ccpph,@totalamount,@status,@approve)", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("@SOID", textBox17.Text);
            cmd.Parameters.AddWithValue("@SODate", System.DateTime.Today);
            cmd.Parameters.AddWithValue("@DDate", dateTimePicker1);
            cmd.Parameters.AddWithValue("@CDept", textBox10.Text);
            cmd.Parameters.AddWithValue("@CName", textBox8.Text);
            cmd.Parameters.AddWithValue("@CID", comboBox3.Text);
            cmd.Parameters.AddWithValue("@ccontectperson", textBox11.Text);
            cmd.Parameters.AddWithValue("@ccpph", textBox16.Text);
            cmd.Parameters.AddWithValue("@TotalAmount", textBox20.Text);
            cmd.Parameters.AddWithValue("@status", "Open");
            cmd.Parameters.AddWithValue("@approve", "applied");
            cmd.Parameters.AddWithValue("@SOprice", textBox21.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Data  Inserted");
            conn.oleDbConnection1.Close();
            conn.oleDbConnection1.Open();
            OleDbCommand cmd1 = new OleDbCommand("insert into soproducts (soid,pid,pqty) values(@soid,@pid,@pqty)", conn.oleDbConnection1);
            cmd1.Parameters.AddWithValue("@soid", textBox17.Text);
            cmd1.Parameters.AddWithValue("@pid", comboBox2.Text);
            cmd1.Parameters.AddWithValue("@pqty", textBox21);
            cmd1.ExecuteNonQuery();
            conn.oleDbConnection1.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {

            try
            {
               conn. oleDbConnection1.Open();
                OleDbCommand cmd = new OleDbCommand("update Customer set CName=@cname,CAddress=@caddress,City=@city,Ph1=@ph1,Ph2=@ph2,ContectPerson=@contectperson,CPPH=@cpph,CEmail=@cemail,CreditLimit=@creditlimit,CStatus=@cstatus,CGroup=@cgroup where cid='" + textBox1.Text + "'", conn.oleDbConnection1);

                cmd.Parameters.AddWithValue("@CID", this.textBox1.Text);
                cmd.Parameters.AddWithValue("@Cname", this.textBox2.Text);
                cmd.Parameters.AddWithValue("@CAddress", this.textBox3.Text);
                cmd.Parameters.AddWithValue("@City", this.textBox4.Text);
                cmd.Parameters.AddWithValue("@PH1", this.textBox5.Text);
                cmd.Parameters.AddWithValue("@PH2", this.textBox6.Text);
                cmd.Parameters.AddWithValue("@Contectperson", this.textBox7.Text);
                cmd.Parameters.AddWithValue("@CPPH", this.textBox12.Text);
                cmd.Parameters.AddWithValue("@CEmail", this.textBox13.Text);
                cmd.Parameters.AddWithValue("@CreditLimit", this.textBox14.Text);
                cmd.Parameters.AddWithValue("@CGroup", this.textBox15.Text);
                cmd.Parameters.AddWithValue("@Cstatus", "active");
                MessageBox.Show("Data Has been Updated");
               conn.oleDbConnection1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Correct data");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           

            if (flag == 0)
            {
                this.comboBox6.Visible = true;
                this.textBox1.Visible = false;
                flag = 1;
            }
            else {
                this.comboBox6.Visible = false;
                this.textBox1.Visible = true;
                flag = 0;
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void textBox23_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from Customer where CID =@CID", conn.oleDbConnection1);
            cmd.Parameters.AddWithValue("CID", comboBox6.Text);
            OleDbDataReader dr = cmd.ExecuteReader();
            DataTable dt = new DataTable();
            dt.Load(dr);
            dataGridView1.DataSource = dt;
            conn.oleDbConnection1.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int c = 0;
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select count(poid) from po where vdept='" + comboBox1.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                c = Convert.ToInt32(dr[0]); c++;
            }
            if (comboBox1.Text == "Consumer")
            {
                textBox17.Text = "Con_00" + c.ToString() + "--" + System.DateTime.Today.Year;
            } if (comboBox1.Text == "HR")
            {
                textBox17.Text = "HR-01" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            if (comboBox1.Text == "Marketing")
            {
                textBox17.Text = "Mar-02" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            if (comboBox1.Text == "Sales")
            {
                textBox17.Text = "sal-03" + c.ToString() + "-" + System.DateTime.Today.Year;
            }
            conn.oleDbConnection1.Close();
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from products  where Pid='" + comboBox2.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox19.Text = dr["PName"].ToString();
                textBox18.Text = dr["BasePrice"].ToString();

            }
            conn.oleDbConnection1.Close();
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.oleDbConnection1.Open();
            OleDbCommand cmd = new OleDbCommand("select * from customer  where CID='" + comboBox3.Text + "'", conn.oleDbConnection1);
            OleDbDataReader dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                textBox8.Text = dr["CName"].ToString();
                textBox10.Text = dr["City"].ToString();
                textBox11.Text = dr["PH1"].ToString();
                textBox16.Text = dr["Contectperson"].ToString();


            }
            conn.oleDbConnection1.Close();
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
          
            int b = Convert.ToInt32(this.textBox18.Text);
            int c = Convert.ToInt32(this.textBox9.Text); 
           int a = b * c;
         
          
           this.textBox37.Text = a.ToString();
            try
            {
                textBox20.Text += comboBox2.Text + Environment.NewLine;
                textBox21.Text += textBox18.Text + Environment.NewLine;
                prd[counter] = comboBox3.Text;
                qty[counter] = Convert.ToInt32(textBox7.Text);
                pprice[counter] = Convert.ToInt32(textBox6.Text);

                counter++;
                
            //    this.textBox37.Text = Convert.ToInt32(this.textBox18.Text ) * Convert.ToInt32(this.textBox9.Text);

                
            }
            catch (Exception ex)
            {
            }
   
        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox36_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox20_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox19_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox26_TextChanged(object sender, EventArgs e)
        {

        }
        }
    }
